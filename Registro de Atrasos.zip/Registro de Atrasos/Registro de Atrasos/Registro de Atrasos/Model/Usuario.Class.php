<?php

class Usuario {
    public function cadastrar_usuario($email, $senha, $tipo) {
        $pdo = new pdo("mysql:host=sql111.infinityfree.com;dbname=if0_36634523_registrodeatraso", "root", "rYKzs1ci8C3");
        $consulta = "INSERT INTO usuario VALUES (null, :email, :senha, :tipo)";

        $consulta_feita = $pdo->prepare($consulta);
        $consulta_feita->bindValue(":email", $email);
        $consulta_feita->bindValue(":senha", $senha);
        $consulta_feita->bindValue(":tipo", $tipo);
        $consulta_feita->execute();
        
        // header('location:../View/login.html');
    }

    public function listar_usuarios() {
        $pdo = new pdo("mysql:host=sql111.infinityfree.com;dbname=if0_36634523_registrodeatraso", "root", "rYKzs1ci8C3");
        $consulta = "select * from usuario order by tipo, email;";
        $consulta_feita = $pdo->prepare($consulta);
        $consulta_feita->execute();

        echo '<table border=1>
        <tr>
            <th colspan=2>Relatório de Usuarios</th>
            
        </tr>
        <tr>
        <th>Email</th>
        <th>Tipo</th>
        </tr>';

        foreach ($consulta_feita as $value) {
            // var_dump($value);
            echo'<tr><td>' .$value['email'] . '</td>';
            echo '<td>'. $value['tipo'] . '</td></tr>';
        }
        echo '</table>';
    }

    public function login($email, $senha) {
        
        try {
            $pdo = new pdo("mysql:host=sql111.infinityfree.com;dbname=if0_36634523_registrodeatraso", "root", "rYKzs1ci8C3");
            $consulta = 'select * from usuario inner join contato on usuario.id = contato.id_usuario where contato.endereco_email = :email and usuario.senha = :senha';
            $consultar = $pdo->prepare($consulta);
            $consultar->bindValue(":email", $email);
            $consultar->bindValue(":senha", $senha);
            $consultar->execute();
            $resultado = $consultar->fetch(PDO::FETCH_ASSOC);
           
            if ($resultado['senha'] == $senha) {
                session_start();
                $_SESSION['id_usuario'] = $resultado['id'];
                $_SESSION['tipo'] = $resultado['tipo'];
                echo $resultado['tipo'];
                switch ($resultado['tipo']) {
                    case 'admin':
                        header("location:../View/Cadastrar/registrar-atraso/ano-turma.php");
                        exit;
                        break;
                    case 'aluno':
                        header("location: ../View/relatorios/index.php");
                        exit;
                        break;
                    default:
                        echo 'deu erro ai, default '. $resultado['tipo'];
                        echo "senha certa pesquisa: " . $resultado['senha'] . ' = senha passada ' . $senha . '<pre>';
                        print_r($resultado);
                        break;
                }

            } else  {
                var_dump($resultado);
                echo '<p>erro ao verificar senha</p><pre>'. print_r($resultado).'</pre>';
            }
        } catch (PDOException $e) {
            echo "Erro com a conexão " . $e;
        } catch (Exception $e) {
            echo "Erro genérico... " . $e;
        }

    }
}
         