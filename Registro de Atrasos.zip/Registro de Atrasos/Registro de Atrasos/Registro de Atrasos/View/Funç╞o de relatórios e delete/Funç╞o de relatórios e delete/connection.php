<?php 
$connection = mysqli_connect('127.0.0.1', 'root', '', 'registro');

if (!$connection) {
    die("Falha na conexão: " . mysqli_connect_error());
}
?>
