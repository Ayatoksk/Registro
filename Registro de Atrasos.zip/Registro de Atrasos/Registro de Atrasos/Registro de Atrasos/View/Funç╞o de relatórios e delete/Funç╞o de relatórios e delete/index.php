<?php 
include "connection.php"; // Certifique-se de que este arquivo define $connection corretamente

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $delete = mysqli_query($connection, "DELETE FROM registro WHERE id = '$id'");
    if (!$delete) {
        die('Erro ao deletar dado: ' . mysqli_error($connection));
    }
}

$select = "SELECT * FROM registro";
$query = mysqli_query($connection, $select);

if (!$query) {
    die('Erro na consulta: ' . mysqli_error($connection));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Deletar um arquivo teste</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <table border="1" cellpadding="5">
    <tr>
      <th>id</th>
      <th>motivo</th>
      <th>data</th>
      <th>id_aluno</th>
      <th>id_usuario</th>
      <th>Operação</th>
    </tr>
    
    <?php 
    $num = mysqli_num_rows($query);
    if ($num > 0) {
        while ($result = mysqli_fetch_assoc($query)) {
            echo "
            <tr>
                <td class='tabela-cell'>{$result['id']}</td>
                <td class='tabela-cell'>{$result['motivo']}</td>
                <td class='tabela-cell'>{$result['data']}</td>
                <td class='tabela-cell'>{$result['id_aluno']}</td>
                <td class='tabela-cell'>{$result['id_usuario']}</td>
                <td class='tabela-cell'>
                   <a href='#' class='btn' onclick='confirmDelete({$result['id']})'>Excluir</a>
  
                </td>
                
            </tr>
            ";
        }
    } else {
        echo "<tr><td colspan='7'>Nenhum dado encontrado</td></tr>";
    }
    ?>
  </table>
  
  <script>
    function confirmDelete(id) {
      if (confirm("Tem certeza que deseja excluir este registro?")) {
        window.location.href = "index.php?id=" + id; // Redireciona para a página de exclusão
      }
    }
  </script>
</body>
</html>
