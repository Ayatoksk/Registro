<?php

require("../../../Model/RelatorioAtrasos.Class.php");

$relatorio = new RelatorioAtrasos();
$relatorio->relatorio_atrasos_todos(); 
?>