<?php 
session_start();
if ($_SESSION['tipo'] != 'admin') {
    echo '<!DOCTYPE html>
    <html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Acesso negado!</title>
    </head>
    <body>
    <script>
        alert("Acesso negado! Você não pode registrar atrasos")
        window.location.href = "../../login/index.php";
    </script>
    </body>
    </html>';
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faça um Regsitro</title>
    <link rel="stylesheet" href="../css/registro.css">
    <style>
        body {
    font-family: Arial, sans-serif;
    background: linear-gradient(135deg, #D37676, #FFBE98);
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    transition: background 2s;
}

body:hover {
    background: linear-gradient(135deg, #FFBE98, #D37676);
}

main {
    background-color: #FFE6E6;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
    text-align: center;
    width: 100%;
    max-width: 500px;
}

h1 {
    font-size: 2.5em;
    color: #D37676;
    margin-bottom: 30px;
    text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.3);
}

form {
    display: flex;
    flex-direction: column;
    align-items: center;
}

.linha {
    margin: 15px 0;
    width: 100%;
}

select,
input[type="submit"] {
    width: calc(100% - 20px);
    padding: 10px;
    font-size: 1em;
    border: 2px solid #D37676;
    border-radius: 6px;
    margin-bottom: 10px;
    box-sizing: border-box;
}

input[type="submit"] {
    background-color: #D37676;
    color: #F1EF99;
    font-size: 1.2em;
    cursor: pointer;
    transition: background-color 0.3s, color 0.3s;
}

input[type="submit"]:hover {
    background-color: #FFE6E6;
    color: #FFF;
}

@media (max-width: 600px) {
    h1 {
        font-size: 2em;
    }

    select,
    input[type="submit"] {
        font-size: 0.9em;
        padding: 8px;
    }

    input[type="submit"] {
        font-size: 1em;
        padding: 8px 16px;
    }
}

    </style>
</head>

<body>
    <main>
        <h1>Registrar atraso</h1>
        <form action="../../../Control/controle-registro.php" method="POST">
            <div class="linha">
                <select name="ano">
                    <option value="1">1° ANO </option>
                    <option value="2">2° ANO </option>
                    <option value="3">3° ANO </option>
                </select>
            </div>
            <div class="linha">
                <select name="turma">
                    <option value="A">A</option>
                    <option value="B">B</option>
                    <option value="C">C</option>
                    <option value="D">D</option>
                </select>
            </div>
            <div class="linha">
                <input type="submit" name="prox" value="Avançar">
            </div>
            <div class="linha">
                <input type="submit" name="registro_turma" value="Relatório por turma">
            </div>
        </form>
    </main>
</body>

</html>