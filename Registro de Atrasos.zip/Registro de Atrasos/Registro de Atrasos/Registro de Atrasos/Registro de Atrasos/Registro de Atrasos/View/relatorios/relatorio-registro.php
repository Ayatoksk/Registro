<?php

require_once('../../Model/Registro.Class.php');

$registro = new Registro();
$registro->relatorio_turma();
?>
