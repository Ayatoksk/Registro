<?php

require("../../Model/Usuario.Class.php");

$alunos = new Usuario();

$alunos->listar_usuarios();

?>