<?php 
    session_start();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página inicial - Atrasos</title>
    <link rel="stylesheet" href="css/registro.css">
    <style>

        body {
    font-family: Arial, sans-serif;
    background: linear-gradient(135deg, #D37676, #FFBE98);
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    transition: background 2s;
}

body:hover {
    background: linear-gradient(135deg, #FFBE98, #D37676);
}

main {
    background-color: #FFE6E6;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
    text-align: center;
    width: 100%;
    max-width: 500px;
}

h1 {
    font-size: 2.5em;
    color: #D37676;
    margin-bottom: 30px;

}

.links {
    display: flex;
    flex-direction: column;
    align-items: center;
}

.opcoes {
    list-style: none;
    padding: 0;
    margin: 0;
    width: 100%;
}

.opcao {
    margin: 15px 0;
    width: 100%;
}

.opcao a {
    display: block;
    text-decoration: none;
    color: #F1EF99;
    font-size: 1.2em;
    padding: 15px;
    background-color: #D37676;
    border-radius: 6px;
    transition: background-color 0.3s, color 0.3s;
    text-align: left;
}

.opcao a:hover {
    background-color: #FFE6E6;
    color: #FFF;
}

@media (max-width: 600px) {
    h1 {
        font-size: 2em;
    }

    .opcao a {
        font-size: 1em;
        padding: 12px;
    }
}

    </style>
</head>
<body>
    <main>
        <h1>O que você quer fazer?</h1>
        <div class="links">
            <ul class="opcoes">
                <li class="opcao">
                    <a href="login/index.php">Login</a>
                </li>
                <li class="opcao">
                    <a href="relatorios/relatorio-registro.php">Relatórios</a>
                </li>
                <?php
                if (isset($_SESSION['tipo']) and $_SESSION['tipo'] == 'admin') {
                    echo '<li class="opcao">
                        <a href="Cadastrar/Usuário/index.php">Cadastrar usuário</a>
                    </li>
                    <li class="opcao">
                        <a href="Cadastrar/Aluno/index.php">Cadastrar aluno</a>
                    </li>
                    <li class="opcao">
                        <a href="Cadastrar/registrar-atraso/ano-turma.php">Registrar atraso</a>
                    </li>
                    <li class="opcao">
                        <a href="relatorios/index.php">Gerar relatório</a>
                    </li>';
                }
                ?>
            </ul>
        </div>
    </main>
</body>
</html>