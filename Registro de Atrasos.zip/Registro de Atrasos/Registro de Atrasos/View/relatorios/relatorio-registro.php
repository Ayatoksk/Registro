
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>relatorio por turma</title>
    <link rel="stylesheet" href="../css/CadastroAluno.css">
</head>

<body>
    <main>
        <h1>Relatório por turma</h1>
        <form action="../../Control/controle-relatorio.php" method="POST">
            <div class="linha">
                <select name="ano" id="ano">
                    <option value="1"> 1° ANO </option>
                    <option value="2"> 2° ANO </option>
                    <option value="3"> 3° ANO </option>
                </select>
            </div>
            <div class="linha">
                <select name="turma" id="turma">
                    <option value="A">A</option>
                    <option value="B">B</option>
                    <option value="C">C</option>
                    <option value="D">D</option>
                </select>
            </div>
            <div class="linha"><input type="submit" name="relatorio_turma" id="relatorio_turma" value="Ver"></div>
        </form>
    </main>
</body>

</html>