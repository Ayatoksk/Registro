
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>relatorio individual</title>
    <link rel="stylesheet" href="../../css/CadastroAluno.css">
</head>

<body>
    <main>
        <h1>relatorio individual</h1>
        <form action="../../Control/controle-relatorio.php" method="POST">
        <div class="linha">
                <label for="id">Informe seu id</label>
            </div>
            <div class="linha">
                <input type="id" name="id" id="id" placeholder="ex:1234..." required>
            </div>
            
            <div class="linha"><input type="submit" name="relatorio_indiv" id="relatorio_indiv" value="Ver"></div>
        </form>
    </main>
</body>

</html>