<?php 
    session_start();
?>
<!DOCTYPE HTML>
<!--
	Dopetrope by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Dopetrope by HTML5 UP</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/style.css" />
	</head>
	<body class="homepage-is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<section id="header">

					<!-- Logo -->
						<h1>Registro de Atrasos</h1>

					<!-- Nav -->
						<nav id="nav">
							<ul>
								
							<?php
               				if (isset($_SESSION['tipo']) and $_SESSION['tipo'] == 'admin') {
								echo(
									'<li>
										<a href="#">Cadastrar</a>
										<ul>
											<li><a class = "a" href="../Cadastrar/Aluno">Aluno</a></li>
											<li><a  class = "a" href="../Cadastrar/Usuário">Usuário</a></li>
											<li><a  class = "a" href="../Cadastrar/registrar-atraso/ano-turma.php">Atraso</a></li>
										</ul>
									</li>'
								);
							}
							?>
								<li class="current"><a href="../index.php">Sair</a></li>
							</ul>
						</nav>

					<!-- Banner -->
						<section id="banner">
							<header>
								
									<img src=images/palestra.png class="img1">
									<h2>Bem-vindo ao nosso site de Registro de Atrasos!</h2>
									<p>Estamos felizes em recebê-lo ao nosso site, seu parceiro confiável para a gestão eficiente de atrasos. Aqui, oferecemos uma solução prática e intuitiva para registrar, monitorar e analisar os atrasos de maneira simples e eficaz.</p>
								
							</header>
						</section>

					<!-- Intro -->
						<section id="intro" class="container">
							<div class="row">
								<div class="col-4 col-12-medium">
								<?php
               						if (isset($_SESSION['tipo']) and $_SESSION['tipo'] == 'admin') {
										echo(
											'<a href="../relatorios/atrasos-aluno/index.php"><button type="submit" class="btn">
												<section class="first">
													<i class="icon solid featured fa-file-alt"></i>
													<header>
														<h2>Relatório geral</h2>
													</header>
													<p>Gerar relatórios completos sobre os atrasos registrados.</p>
												</section>
											</button></a>'
										);
									}
								?>
								</div>

								<div class="col-4 col-12-medium">
								<?php
               						if (isset($_SESSION['tipo']) and $_SESSION['tipo'] == 'admin') {
										echo(
											'<a href="../delete-registro/index.php"><button type="submit" class="btn">
												<section class="first">
													<i class="icon solid featured fa-pencil-ruler"></i>
													<header>
														<h2>Excluir registro</h2>
													</header>
													<p>excluir resgitro indesejado do sistema.</p>
												</section>
											</button></a>'
										);
									}
								?>
								</div>

								<div class="col-4 col-12-medium">
								<?php
               						if (isset($_SESSION['tipo']) and $_SESSION['tipo'] == 'admin') {
										echo(
											'<a href="../relatorios/relatorio-registro.php"><button type="submit" class="btn">
												<section class="first">
													<i class="icon solid featured fa-file-alt"></i>
													<header>
														<h2>Relatório por turma</h2>
													</header>
													<p>Gerar relatórios completos sobre os atrasos por turma.</p>
												</section>
											</button></a>'
										);
									}
								?>
								</div>
							
								<div class="col-12 col-12-medium">
								<?php
               						if (isset($_SESSION['tipo']) and $_SESSION['tipo'] == 'aluno') {
										echo(
											'<a href="../relatorios/relatorio-usuario.php"><button type="submit" class="btn">
												<section class="first">
													<i class="icon solid featured fa-file-alt"></i>
													<header>
														<h2>Relatório geral</h2>
													</header>
													<p>Gerar relatórios completos sobre os atrasos registrados.</p>
												</section>
											</button></a>'
										);
									}
								?>
								</div>
		

							
							</div>
						</section>
				</section>

			<!-- Main -->
				<section id="main">
					<div class="container">
						<div class="row">
							<div class="col-12">

								<!-- Portfolio -->
									

			<!-- Footer -->
				<section id="footer">
					<div class="container">
						<div class="row">
							<div class="col-4 col-12-medium">
								<section>
									
							</div>
							<div class="col-4 col-6-medium col-12-small">
								<header>
										<h2 class="pe">Acompanhe pelas redes sociais!</h2>
									</header>
									<ul class="social" class="col-4 col-6-medium col-12-small">
										<li><a class="icon brands fa-instagram" href="#"><span class="label">Facebook</span></a></li>
										<li><a class="icon brands fa-twitter" href="#"><span class="label">Twitter</span></a></li>
										<li><a class="icon brands fa-facebook" href="#"><span class="label">Dribbble</span></a></li>
									</ul>
								</section>
							</div>
							<div class="col-4 col-6-medium col-12-small">
								
							</div>
							<div class="col-4 col-12-medium">
								
							</div>
							<div class="col-12">

								<!-- Copyright -->
									<div id="copyright">
										<ul class="links">
											<li>&copy; Untitled. All rights reserved.</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
										</ul>
									</div>

							</div>
						</div>
					</div>
				</section>

		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>