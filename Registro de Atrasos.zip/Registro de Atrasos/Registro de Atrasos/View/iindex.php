<?php 
    session_start();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página inicial - Atrasos</title>
    <link rel="stylesheet" href="css/InicialAtrasos.css">
    <style>

     

    </style>
</head>
<body>
    <main>
        <h1>O que você quer fazer?</h1>
        <div class="links">
            <ul class="opcoes">
                <li class="opcao">
                    <a href="login/index.php">Login</a>
                </li>
                <li class="opcao">
                    <a href="relatorios/relatorio-registro.php">Relatórios</a>
                </li>
                <?php
                if (isset($_SESSION['tipo']) and $_SESSION['tipo'] == 'admin') {
                    echo '<li class="opcao">
                        <a href="Cadastrar/Usuário/index.php">Cadastrar usuário</a>
                    </li>
                    <li class="opcao">
                        <a href="Cadastrar/Aluno/index.php">Cadastrar aluno</a>
                    </li>
                    <li class="opcao">
                        <a href="Cadastrar/registrar-atraso/ano-turma.php">Registrar atraso</a>
                    </li>
                    <li class="opcao">
                        <a href="relatorios/index.php">Gerar relatório</a>
                    </li>';
                }
                ?>
            </ul>
        </div>
    </main>
</body>
</html>