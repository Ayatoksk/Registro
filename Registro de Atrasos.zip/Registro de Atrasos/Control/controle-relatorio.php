<?php
require_once('../Model/RelatorioAtrasos.Class.php');

if (isset($_POST['relatorio_turma'])) {
    $ano = $_POST['ano'];
    $turma = $_POST['turma'];

    echo $ano;
    echo $turma;
    
    $registro = new RelatorioAtrasos();
    $registro->relatorio_turma($turma, $ano);
}



if (isset($_POST['relatorio_indiv'])) {
    $id = $_POST['id'];
    $alunos = new RelatorioAtrasos();
    $alunos->relatorio_atrasos_individual($id);
}





?>