<?php



class Registro {
    public function cadastrar_registro($motivo, $aluno) {
        $pdo = new pdo("mysql:host=localhost; dbname=nome_database", "root", "");
        $consulta = "INSERT INTO registro VALUES (null,:motivo, curdate(),:id_aluno,:id_usuario)";

        session_start();

        $consulta_feita = $pdo->prepare($consulta);
        $consulta_feita->bindValue(":id_aluno", $aluno);
        $consulta_feita->bindValue(":id_usuario", $_SESSION['id_usuario']);
        $consulta_feita->bindValue(":motivo", $motivo);
        $consulta_feita->execute();

        header("location:../View/tamplete/index.php");
    }


    
}