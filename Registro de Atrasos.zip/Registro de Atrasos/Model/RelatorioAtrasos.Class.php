<?php
require_once __DIR__. '/../Model/Registro.Class.php';
require_once __DIR__. '/../View/fpdf/fpdf.php';

Class RelatorioAtrasos{
   private $pdo;

    public function __construct() {
        $this->pdo = new PDO("mysql:host=localhost;dbname=nome_database", "root", "");
    }

    

    public function relatorio_atrasos_todos() {
        $consulta = "SELECT * from aluno inner join registro on aluno.id =  registro.id_aluno order by data";
        $consulta_feita = $this->pdo->prepare($consulta);
        $consulta_feita->execute();

        $pdf = new FPDF();
        $pdf->AddPage();
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(0, 10, mb_convert_encoding("Relatório de atrasos - Todos os Alunos", 'ISO-8859-1', 'UTF-8'), 0, 1, 'C');
        $pdf->SetFont('Arial', '', 12);

        $header = false;
        foreach ($consulta_feita as $value) {
            if (!$header) {
                $pdf->Cell(60, 8, 'Nome', 1, 0, 'C');
                $pdf->Cell(20, 8, 'Ano', 1, 0, 'C');
                $pdf->Cell(20, 8, 'Turma', 1, 0, 'C');
                $pdf->Cell(30, 8, 'Motivo', 1, 0, 'C');
                $pdf->Cell(30, 8, 'Data', 1, 1, 'C');
                $header = true;
            }
            $pdf->Cell(60, 8, mb_convert_encoding($value['nome'], 'ISO-8859-1', 'UTF-8'), 1, 0, 'C');
            $pdf->Cell(20, 8, mb_convert_encoding($value['ano'], 'ISO-8859-1', 'UTF-8'), 1, 0, 'C');
            $pdf->Cell(20, 8, mb_convert_encoding($value['turma'], 'ISO-8859-1', 'UTF-8'), 1, 0, 'C');
            $pdf->Cell(30, 8, mb_convert_encoding($value['motivo'], 'ISO-8859-1', 'UTF-8'), 1, 0, 'C');
            $pdf->Cell(30, 8, mb_convert_encoding($value['data'], 'ISO-8859-1', 'UTF-8'), 1, 1, 'C');
        }
        $pdf->Output();
    }

    public function relatorio_turma($turma, $ano) {
        
    
        $consulta = "SELECT * from aluno inner join registro on aluno.id = registro.id_aluno where turma = :turma and ano = :ano order by data";
        $consulta_feita = $this->pdo->prepare($consulta);
        $consulta_feita->bindValue(":turma", $turma);
        $consulta_feita->bindValue(":ano", $ano);
        $consulta_feita->execute();

        $pdf = new FPDF();
        $pdf->AddPage();
        $pdf->SetFont('arial', 'B', 12);
        $pdf->Cell(0, 5, utf8_decode("Relatório de registros da turma"). $turma. $ano, 0, 1, 'C');

        $pdf->Cell(80, 5, 'nome', 1, 0, 'L');
        $pdf->Cell(25, 5, 'ano', 1, 0, 'L');
        $pdf->Cell(25, 5, 'turma', 1, 0, 'C');
        $pdf->Cell(25, 5, 'data', 1, 0, 'C');
        $pdf->Cell(25, 5, 'otivo', 1, 1, 'C');
        $pdf->SetFont('arial', '', 12);
    
        foreach ($consulta_feita as $reg) {
            $pdf->Cell(80, 5, utf8_decode($reg['nome']), 1, 0, 'L');
            $pdf->Cell(25, 5, utf8_decode($reg['ano']), 1, 0, 'L');
            $pdf->Cell(25, 5, utf8_decode($reg['turma']), 1, 0, 'C');
            $pdf->Cell(25, 5, utf8_decode($reg['data']), 1, 0, 'C');
            $pdf->Cell(25, 5, utf8_decode($reg['motivo']), 1, 1, 'C');
        }
        function _checkoutput() {
            if (headers_sent()) {
                die('Erro: Não é possível gerar o PDF porque a saída já foi iniciada.');
            }
        }
        $pdf->Output();
    }
    
    public function relatorio_atrasos_individual($id) {
        $consulta = "SELECT * from aluno inner join registro on aluno.id = registro.id_aluno where id = :id_aluno";
        $consulta_feita = $this->pdo->prepare($consulta);
        $consulta_feita->bindValue(":id_aluno", $id);
        $consulta_feita->execute();
    
        $pdf = new FPDF();
        $pdf->AddPage();
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(0, 10, mb_convert_encoding("Seus atrasos", 'ISO-8859-1', 'UTF-8'), 0, 1, 'C');
        $pdf->SetFont('Arial', '', 12);
        $pdf->Cell(60, 10, mb_convert_encoding('Motivo', 'ISO-8859-1', 'UTF-8'), 1, 0, 'C');
        $pdf->Cell(60, 10, mb_convert_encoding('Dia de atraso', 'ISO-8859-1', 'UTF-8'), 1, 0, 'C');
        $pdf->Cell(60, 10, mb_convert_encoding('Endereço de e-mail', 'ISO-8859-1', 'UTF-8'), 1, 1, 'C');
    
        foreach ($consulta_feita as $value) {
            $pdf->Cell(60, 10, mb_convert_encoding($value['motivo'], 'ISO-8859-1', 'UTF-8'), 1, 0, 'C');
            $pdf->Cell(60, 10, mb_convert_encoding($value['data'], 'ISO-8859-1', 'UTF-8'), 1, 0, 'C');
            $pdf->Cell(60, 10, mb_convert_encoding($value['endereco_email'], 'ISO-8859-1', 'UTF-8'), 1, 1, 'C');
        }
    
        $pdf->Output();
    }
}


?>